Autor: REGINALDO GREGÓRIO DE SOUZA NETO
RA: 2252813

Para compilar o arquivo basta executar o comando "make"
no terminal integrado dentro da pasta.