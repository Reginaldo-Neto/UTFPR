import sys
import numpy as np
from sklearn import svm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn import tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import confusion_matrix

# Carrega os dados....
tr = np.loadtxt('treinamento.txt');
ts = np.loadtxt('teste.txt');
y_test = ts[:,-1]
y_train = tr[:,-1]
X_train = tr[:, 1 : -1]
X_test = ts[:, 1 : -1]


X_train, X_testL, y_train, y_testL = train_test_split(X_train, y_train, test_size=0.10, random_state=42)#Separa os conjuntos aleatoriamente
        
# KNN classifier
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)

neigh = KNeighborsClassifier(n_neighbors=3, metric='manhattan')
neigh.fit(X_train, y_train)
print('-------------------------KNN--------------------------\n')
print(neigh.predict(X_test))
print(classification_report(y_test, neigh.predict(X_test)))
print(confusion_matrix(y_test, neigh.predict(X_test)))
print('------------------------------------------------------\n')
        

# SVM sem grid search
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)

clf = svm.SVC()
clf.fit(X_train, y_train)
print('-------------------------SVM--------------------------\n')
print(clf.predict(X_test))
print(classification_report(y_test, clf.predict(X_test)))
print(confusion_matrix(y_test, clf.predict(X_test)))
print('------------------------------------------------------\n')


# MLP 
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)
        
clf = MLPClassifier(solver='adam', alpha=1e-5, hidden_layer_sizes=(100, 100, 100), random_state=1)
clf.fit(X_train, y_train)
print('-------------------------MLP--------------------------\n')
print(clf.predict(X_test))
print(classification_report(y_test, clf.predict(X_test)))
print(confusion_matrix(y_test, clf.predict(X_test)))
print('------------------------------------------------------\n')

# Random Forest Classifier
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)

clf = RandomForestClassifier(n_estimators=130, max_depth=None, random_state=1)
clf.fit(X_train, y_train)
print('-------------------------Random Forest----------------\n')
print(clf.predict(X_test))
print(classification_report(y_test, clf.predict(X_test)))
print(confusion_matrix(y_test, clf.predict(X_test)))
print('------------------------------------------------------\n')

# DT - Decision Tree
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.fit_transform(X_test)

clf = tree.DecisionTreeClassifier()
clf = clf.fit(X_train, y_train)
print('----------------------DT------------------------------\n')
print(clf.predict(X_test))
print(classification_report(y_test, clf.predict(X_test)))
print(confusion_matrix(y_test, clf.predict(X_test)))
print('------------------------------------------------------\n')