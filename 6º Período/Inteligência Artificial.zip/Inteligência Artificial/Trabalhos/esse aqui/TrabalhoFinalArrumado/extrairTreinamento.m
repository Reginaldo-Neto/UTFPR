fotos = dir("*.bmp");

arq = fopen('treinamento.txt', 'w');
for i=1:size(fotos)
    [img, map] = imread(fullfile(fotos(i).name)) ;

    [img, map] = ind2rgb(img, map);

    [img, map] = imresize([img, map],[256 256]);

    image = [img, map];
    
    if arq == -1, error('Erro ao abrir o arquivo'); end

    if i < 81
        image = imcrop(image, [64 64 160 128]);
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '0\n');
    elseif i < 140 && i > 80
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '1\n');
    elseif i < 173 && i > 139
        image = imcrop(image, [64 64 160 128]);
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '2\n');
    elseif i < 203 && i > 172
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '3\n');
    elseif i > 202
        image = imcrop(image, [0 0 256 80]);
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '4\n');
    end
end
fclose(arq);