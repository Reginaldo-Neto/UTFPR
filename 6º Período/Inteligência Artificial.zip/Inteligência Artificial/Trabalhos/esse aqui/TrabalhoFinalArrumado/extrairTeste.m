fotos = dir("*.bmp");

arq = fopen('teste.txt', 'w');
for i=1:size(fotos)
    [img, map] = imread(fullfile(fotos(i).name)) ;

    [img, map] = ind2rgb(img, map);

    image = [img, map];

    if arq == -1, error('Erro ao abrir o arquivo'); end

    if i < 36
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '0\n');
    elseif i < 61 && i > 35
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '1\n');
    elseif i < 74 && i > 60
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '2\n');
    elseif i < 86 && i > 73
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '3\n');
    elseif i > 85
        image = imresize(image,[256 256]);
        fprintf(arq, '%f ', image);
        fprintf(arq, '4\n');
    end
end
fclose(arq);