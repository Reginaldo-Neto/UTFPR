text=importdata('nomesTreinamentos.txt');

f=fopen('resultadoTreinamento.txt','w');
fprintf(f,'P;B;C;\n');
for a = 1:1000
    if a < 101
        classe = 0;
    elseif a < 201
        classe = 1;
    elseif a < 301
        classe = 2;
    elseif a < 401
        classe = 3;
    elseif a < 501
        classe = 4;
    elseif a < 601
        classe = 5;
    elseif a < 701
        classe = 6;
    elseif a < 801
        classe = 7;
    elseif a < 901
        classe = 8;
    elseif a < 1001
        classe = 9;
    end

    caminho = './Imagens_Treinamento';
    recebe = text{a};
    var = strcat(caminho,recebe);
    img = imread(var);
    disp(img)
    % soma os pixels Preto automatico%
    somaPreto = sum(img == 255);
    somaPreto = sum(somaPreto);
    disp(somaPreto)

    % soma os pixels brancos automatico%
    somaBranco = sum(img == 0);
    somaBranco = sum(somaBranco);
    disp(somaBranco)
    % fprintf(f,'Nome do arquivo: %s\n', text{a}); %
    fprintf(f,'%i; %i; %.0f;\n',somaPreto, somaBranco, classe);
    % fprintf('\n'); %
end

fclose(f);