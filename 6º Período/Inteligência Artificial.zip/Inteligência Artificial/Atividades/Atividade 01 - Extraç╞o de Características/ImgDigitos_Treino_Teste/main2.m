text=importdata('Nomes_Teste.txt');


%abre o arquivo para alteração
f=fopen('testes.txt','w');
fprintf(f,'P;B;C;\n');
for a = 1:100

    caminho = 'Imagens_Teste'
    recebe = text{a}
    caminhoCompleto = strcat(caminho,recebe)
    img = imread(caminhoCompleto)
    %disp(img)
    % soma os pixels Preto automatico%
    somaPreto = sum(img == 255)
    somaPreto = sum(somaPreto)
    disp(somaPreto)

    % soma os pixels brancos automatico%
    somaBranco = sum(img == 0)
    somaBranco = sum(somaBranco)
    %disp(somaBranco)
    fprintf(f,'%i; %i; %i;\n',somaPreto, somaBranco, 9);
    fprintf('\n');
end

fclose(f);