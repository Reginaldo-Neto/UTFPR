import math
num = int(input("entre com o numero: "))


valor = (num * math.pi)/256
final = math.sin(valor)

print("\nsen: ", final)