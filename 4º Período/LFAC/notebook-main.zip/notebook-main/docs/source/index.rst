====================
The Jupyter Notebook
====================


.. image:: ./_static/images/notebook-running-code.png

* `Installation <https://jupyter.readthedocs.io/en/latest/install.html>`_
* `Starting the Notebook <https://jupyter.readthedocs.io/en/latest/running.html>`_

.. toctree::
   :maxdepth: 2

   user-documentation
   configuration
   contributor
