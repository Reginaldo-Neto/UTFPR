import sys

from notebook.app import main

sys.exit(main())
