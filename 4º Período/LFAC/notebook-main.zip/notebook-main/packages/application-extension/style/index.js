import '@jupyter-notebook/application/style/index.js';
import '@lumino/widgets/style/index.js';

import './base.css';
