const func = require('@jupyterlab/testutils/lib/jest-config');
module.exports = func(__dirname);
