/**
 * Exemplo de código para verificar chamada de sistema
 * Gerar assembly: gcc -S scanf_ex.c -oscanf_ex.dump
 * Compilar: gcc scanf_ex.c -oscanf_ex
 */

#include<stdio.h>

int main() {
    int valor = 0;
    
    printf("Digite um valor inteiro: ");
    scanf("%d", &valor);
    printf("Valor lido: %d", valor);
    
    return 0;
}
