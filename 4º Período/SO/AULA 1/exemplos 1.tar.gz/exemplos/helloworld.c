/**
 * Exemplo de código para verificar chamada de sistema
 * Gerar assembly: gcc -S helloworld.c -ohelloworld.s
 * Compilar: gcc helloworld.c -ohelloworld
 * Dump do binario: objdump -d helloworld > helloword.dump
 * 
 */

#include<stdio.h>

int main() {
    printf("Hello World! :-)\n");
    return 0;
}
