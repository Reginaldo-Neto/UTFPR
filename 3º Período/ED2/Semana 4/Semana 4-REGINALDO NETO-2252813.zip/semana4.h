int SelectionMinK(int* v, int n, int k);
int QuickMinK(int *v, int e, int d, int k);
int* random_vector_unique_elems(int n, int seed);
