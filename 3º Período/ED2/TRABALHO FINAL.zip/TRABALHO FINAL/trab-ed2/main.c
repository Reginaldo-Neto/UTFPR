#include <stdio.h>
#include <stdlib.h>
#include "buffers/bufferEntrada.h"
#include "buffers/bufferSaida.h"
#include "splitFile/split.h"
#include "merge/kway.h"

//B = max de bytes S = tamanho do buffer de saida
void ordenacao_externa_kvias(char* entrada,int B,int S,char* saida){
  remove(saida);
  int qntEntrada = (B-S);
  printf("AQUI %d\n",qntEntrada);
  int E = 0;//tamanho do arquivo de entrada
  int qntEntradas = splitFile("entrada.dat",qntEntrada,&E);
  printf("AQUI2 %d\n",E);
  int K = (int)(E/B);
  printf("AQUI3 %d\n",K);
  // int sizeBufferEntrada = (int)(qntEntrada/K);
  // sizeBufferEntrada = (long)(sizeBufferEntrada/1024);
  // printf("AQUI4 %d\n",);

  // SAIDA* Bsaida = saida_criar(saida,S);
  // printf("BUFFER DE SAIDA CRIADO\n");

  // ENTRADA* entradas[qntEntradas];
  // char nomeEntrada[100];
  // for (int i = 0; i < qntEntradas; i++){
  //   sprintf(nomeEntrada,"out%d.bin",i);
  //   entradas[i] = entrada_criar(nomeEntrada,sizeBufferEntrada);
  // }
  // printf("BUFFERS DE ENTRADA CRIADOS\n"); 

  // kway(qntEntradas,entradas,Bsaida);
  // saida_despejar(Bsaida);
  // printf("ARQUIVO FINAL COMPLETO\n"); 

  // saida_destruir(&Bsaida);
  // for (int i = 0; i < qntEntradas; i++){
  //   entrada_destruir(&entradas[i]);
  //   sprintf(nomeEntrada,"out%d.bin",i);
  //   remove(nomeEntrada);
  // }
  // printf("BUFFERS E ARQUIVOS TEMPORARIOS DELETADOS\n");
  
}

int main(){
  // char entrada[] = "entrada.dat";
  // char saida[] = "saida.bin";
  int B = 8388608;
  int S = (int)(B/8);

  ordenacao_externa_kvias("entrada.dat",B,S,"saida.bin");

  // ENTRADA* buffer = entrada_criar("saida.bin",50);
  // entrada_imprimir(buffer);
  // return 0;
}