#pragma once
#include <stdint.h>
#include <stdlib.h>
#include<limits.h>
#include<stdbool.h>
#include <stdio.h>
#include "../buffers/bufferEntrada.h"
#include "../buffers/bufferSaida.h"

void kway(int qnt,ENTRADA* entradas[qnt], SAIDA* saida);

