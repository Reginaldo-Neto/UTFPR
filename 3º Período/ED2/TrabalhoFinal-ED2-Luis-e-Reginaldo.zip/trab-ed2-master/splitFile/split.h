#pragma once
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "../gerador/big_file.h"

int splitFile(char* fileName, int outSize);