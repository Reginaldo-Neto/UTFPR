#ifndef __UTILS__
#define __UTILS__

int* criar_vetor_ordenado(int n);
void embaralhar(int *v, int ini, int fim);

#endif
