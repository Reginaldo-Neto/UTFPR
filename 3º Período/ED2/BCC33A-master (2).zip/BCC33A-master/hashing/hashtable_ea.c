#include <stdlib.h>
#include "hashtable_ea.h"


int THEA_Hash(THEA* TH, int chave, int k)
{

}

THEA* THEA_Criar(int m){

}

int THEA_Inserir(THEA *TH, int chave, int valor){

}

int THEA_Buscar(THEA *TH, int chave){


}

void THEA_Remover(THEA* TH, int chave){

}