#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "asciitrie.h"

ASCIITrie* AT_Buscar_R(ASCIITrie* T, unsigned char *chave, 
    int n, int p){

}

ASCIITrie* AT_Buscar(ASCIITrie* T, unsigned char *chave){

}

ASCIITrie* AT_Criar(){

}

void AT_Inserir_R(ASCIITrie **T, unsigned char *chave, int val,
    int n, int p){

}

void AT_Inserir(ASCIITrie **T, unsigned char *chave, 
    int val){

}

void AT_Remover_R(ASCIITrie **T, unsigned char *chave, int n,
    int p){

}

void AT_Remover(ASCIITrie **T, unsigned char *chave){

}

void AT_Imprimir_R(ASCIITrie* T, int nivel, unsigned char c){

}

void AT_Imprimir(ASCIITrie* T){

}
