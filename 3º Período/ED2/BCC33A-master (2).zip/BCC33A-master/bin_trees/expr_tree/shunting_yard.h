#pragma once

char* shunting_yard(const char* expression);

