#include <stdio.h>
#include "shunting_yard.h"
#include "exprtree.h"

int main(int argc, char** argv){



}
