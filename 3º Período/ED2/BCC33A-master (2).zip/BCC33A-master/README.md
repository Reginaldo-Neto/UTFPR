# BCC33A
Repositório GIT para a Disciplina de Algoritmos e Estruturas de Dados 2 (BCC33A), da UTFPR Campo Mourão

Clone-o para obter códigos para estudar e usar nas aulas práticas!
