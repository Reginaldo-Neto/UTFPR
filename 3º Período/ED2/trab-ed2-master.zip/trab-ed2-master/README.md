# Trabalho de estrutura de dados 2


## adiciona as mudanças
`git add .`

## commita as mudanças
`git commit -m "comentário sobre as mudanças"`

## cria e "entra" em uma nova branch
`git checkout -b nome-da-nova-branch`

## sobe as mudanças para o github
`git push origin nome-da-nova-branch`



## baixa o repo
`git clone https://github.com/glob-gall/trab-ed2.git`


## pega as mudanças da nome-da-branch
`git pull origin nome-da-branch`
