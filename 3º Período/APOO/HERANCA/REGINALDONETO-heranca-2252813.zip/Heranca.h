#include <iostream>
#include <string>
#include <stdlib.h>

void printa(); //PRINTA A LISTA, FILA OU PILHA NA TELA
void add(int ele); //ADICIONA UM ELEMENTO NA LISTA, FILA OU PILHA
void remove(int ele); //REMOVE TODOS OS ELEMENTOS IGUAIS A ESSE NA LISTA
void remove(); //REMOVE O PRIMEIRO ELEMENTO DA FILA
void remove(); //REMOVE O ELEMENTO DO TOPO DA PILHA